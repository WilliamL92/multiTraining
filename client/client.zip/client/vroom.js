const config = {
	type: Phaser.AUTO,
	width: 1600,
	height: 900,
	physics: {
	    default: 'matter',
	    matter: {
	        enableSleeping: true,
	        gravity: {
	            y: 0
	        },
	        debug: {
	            showBody: true,
	            showStaticBody: true
	        }
	    }
	},
	scene: {
		preload,
		create,
		update
	}
}

var player;
var cursors;
var velocity = 0;

const game = new Phaser.Game(config)

function preload() {
	this.load.image('map','assets/map.png');
	this.load.image('car','assets/car.png');
}


function create() {
	this.add.image(1300,500, 'map');
	player = this.matter.world.physics.add.image( 1300, 500, 'car');

	cursors = this.input.keyboard.createCursorKeys();
}

function update() {
	
	if (cursors.up.isDown)
    {
    	velocity = velocity + 10;
        player.setVelocityY(velocity);      
    }
    else if (cursors.down.isDown)
    {
    	velocity = velocity - 10;
        player.setVelocityY(velocity);
    }else{
    	if(velocity > 0){
    		velocity = velocity - 5;
    		player.setVelocityY(velocity);
    	}else if(velocity < 0){
    		velocity = velocity + 5;
    		player.setVelocityY(velocity);
    	}
    	
    }
    player.setAngularAcceleration(5)
}